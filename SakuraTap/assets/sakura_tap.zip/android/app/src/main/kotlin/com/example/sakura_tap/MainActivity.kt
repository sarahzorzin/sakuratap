package com.example.sakura_tap

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
